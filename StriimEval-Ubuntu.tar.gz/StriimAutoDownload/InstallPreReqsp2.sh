# PATH Entry
eval "$(/home/linuxbrew/.linuxbrew/bin/brew shellenv)"
# Install Homebrew's dependencies
sudo apt-get -y install build-essential
# Install other dependencies and prep for docker
sudo apt-get update
sudo apt-get -y install \
    ca-certificates \
    gnupg \
    lsb-release
# Grab Docker's official key:
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
# Docker, Set Up Stable Repository
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
# Docker install
sudo apt-get update
sudo apt-get -y install docker-ce docker-ce-cli containerd.io
./InstallStriim.sh