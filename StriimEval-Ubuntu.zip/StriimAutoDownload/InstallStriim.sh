# Download Striim 4.0.5
curl -O https://s3-us-west-1.amazonaws.com/striim-downloads/Releases/4.0.5/Striim_4.0.5.tgz
# tar Striim tgz file
sudo tar zxvf Striim_4.0.5.tgz -C /opt
# Grant permissions to current user
sudo chmod 774 /opt/Striim
# Copy configuration file with defaults
cp -f ~/Documents/startUp.properties /opt/Striim/conf/
# Configure config with default values (username = password)
/opt/Striim/bin/sksConfig.sh

# Future: Create ways to download docker images directly, set up command lines to run docker images.
