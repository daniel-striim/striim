# Install Java 8
sudo apt -y install openjdk-8-jre-headless
# Install Curl
sudo apt -y install curl

# Install GIT
sudo apt -y install git-all
# Install HomeBrew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
#Install network tools
sudo apt -y install net-tools
./InstallPreReqsp2.sh